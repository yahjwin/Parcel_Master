using UnityEngine;

public class DropZone : MonoBehaviour
{
    public int zoneType;
    public GameManager gameManager;

    private void OnTriggerEnter2D(Collider2D other)
    {
        BoxData box = other.GetComponent<BoxData>();
        if (box == null) return;

        if (box.isProcessed) return;
        box.isProcessed = true;

        Debug.Log("�ڽ� Ÿ��: " + box.boxType + " / �� Ÿ��: " + zoneType);

        if (box.boxType == zoneType)
        {
            Debug.Log("����!");
            gameManager.Correct();
        }
        else
        {
            Debug.Log("����!");
            gameManager.Wrong();
        }

        Destroy(other.gameObject);
    }
}